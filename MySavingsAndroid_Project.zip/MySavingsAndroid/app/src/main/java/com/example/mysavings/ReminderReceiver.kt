package com.example.mysavings

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("savings", Context.MODE_PRIVATE)
        val channelId = prefs.getString("channel_id", "saving_reminders_default") ?: "saving_reminders_default"
        if (Build.VERSION.SDK_INT >= 26) {
            val soundText = prefs.getString("sound_uri", "") ?: ""
            val sound = if (soundText.isBlank()) null else Uri.parse(soundText)
            val channel = NotificationChannel(channelId, "Savings reminders", NotificationManager.IMPORTANCE_DEFAULT)
            channel.setSound(sound, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Savings reminder")
            .setContentText("It's time to add today's savings to My Savings.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}
