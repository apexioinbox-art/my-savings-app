package com.example.mysavings

import android.app.*
import android.content.*
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Saving(val id: Long, val date: String, val amount: Int, val done: Boolean)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("savings", MODE_PRIVATE) }
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickSound = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            prefs.edit().putString("sound_uri", uri?.toString() ?: "").apply()
            recreateReminderChannel(prefs)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        recreateReminderChannel(prefs)
        if (Build.VERSION.SDK_INT >= 33) askNotifications.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        setContent { SavingsScreen(prefs, this) }
    }
    fun launchSoundPicker(intent: Intent) { pickSound.launch(intent) }

    private fun recreateReminderChannel(prefs: android.content.SharedPreferences) {
        if (Build.VERSION.SDK_INT >= 26) {
            val uriText = prefs.getString("sound_uri", "") ?: ""
            val channelId = "saving_reminders_" + uriText.hashCode().toString().replace("-", "n")
            val manager = getSystemService(NotificationManager::class.java)
            val sound = if (uriText.isBlank()) null else Uri.parse(uriText)
            val channel = NotificationChannel(channelId, "Savings reminders", NotificationManager.IMPORTANCE_DEFAULT)
            channel.setSound(sound, android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            manager.createNotificationChannel(channel)
            prefs.edit().putString("channel_id", channelId).apply()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsScreen(prefs: android.content.SharedPreferences, context: Context) {
    var rows by remember { mutableStateOf(loadRows(prefs)) }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var amount by remember { mutableStateOf("1") }
    var target by remember { mutableStateOf(prefs.getInt("target", 5050).toString()) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var reminder1 by remember { mutableStateOf(prefs.getString("r1", "08:00") ?: "08:00") }
    var reminder2 by remember { mutableStateOf(prefs.getString("r2", "13:00") ?: "13:00") }
    var reminder3 by remember { mutableStateOf(prefs.getString("r3", "20:00") ?: "20:00") }
    var soundLabel by remember { mutableStateOf(if ((prefs.getString("sound_uri", "") ?: "").isBlank()) "Default notification sound" else "Custom sound selected") }
    var showSettings by remember { mutableStateOf(false) }
    val total = rows.filter { it.done }.sumOf { it.amount }
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val todayTotal = rows.filter { it.done && it.date == today }.sumOf { it.amount }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF80CBC4)) else lightColorScheme(primary = Color(0xFF087F70), secondary = Color(0xFFFFB74D))
    MaterialTheme(colorScheme = scheme) {
        Scaffold(topBar = {
            TopAppBar(title = { Text("My Savings", fontWeight = FontWeight.Bold) },
                actions = { IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Notifications, "Settings") } })
        }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("OVERALL SAVINGS", fontSize = 12.sp)
                            Text("₹$total", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Target ₹${target.toIntOrNull() ?: 0}  •  Today's savings ₹$todayTotal")
                            val t = (target.toIntOrNull() ?: 0).coerceAtLeast(1)
                            LinearProgressIndicator(progress = { (total.toFloat() / t).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(top = 10.dp))
                            Text("${((total.toFloat() / t) * 100).toInt().coerceIn(0,100)}% completed", modifier = Modifier.padding(top = 5.dp))
                        }
                    }
                }
                item {
                    Text("Add a savings entry", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("Amount in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        val a = amount.toIntOrNull()
                        if (date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && a != null && a > 0) {
                            rows = (rows + Saving(System.currentTimeMillis(), date, a, false)).sortedBy { it.date }
                            saveRows(prefs, rows); amount = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add date & amount") }
                }
                if (showSettings) {
                    item {
                        Card {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                OutlinedTextField(target, { target = it.filter(Char::isDigit); prefs.edit().putInt("target", target.toIntOrNull() ?: 0).apply() }, label = { Text("Savings target ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                Row(verticalAlignment = Alignment.CenterVertically) { Text("Dark theme"); Spacer(Modifier.weight(1f)); Switch(dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() }) }
                                Text("Daily reminder times (24-hour HH:MM)")
                                OutlinedTextField(reminder1, { reminder1 = it; prefs.edit().putString("r1", it).apply() }, label = { Text("Reminder 1") }, singleLine = true)
                                OutlinedTextField(reminder2, { reminder2 = it; prefs.edit().putString("r2", it).apply() }, label = { Text("Reminder 2") }, singleLine = true)
                                OutlinedTextField(reminder3, { reminder3 = it; prefs.edit().putString("r3", it).apply() }, label = { Text("Reminder 3") }, singleLine = true)
                                Button(onClick = {
                                    listOf(reminder1, reminder2, reminder3).forEachIndexed { i, time -> scheduleDaily(context, time, i) }
                                }, modifier = Modifier.fillMaxWidth()) { Text("Save & schedule reminders") }
                                Text("Reminder sound", fontWeight = FontWeight.SemiBold)
                                Text(soundLabel, fontSize = 12.sp)
                                OutlinedButton(onClick = {
                                    val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose savings reminder sound")
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                        val current = prefs.getString("sound_uri", "") ?: ""
                                        if (current.isNotBlank()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, android.net.Uri.parse(current))
                                    }
                                    (context as? MainActivity)?.launchSoundPicker(picker)
                                }, modifier = Modifier.fillMaxWidth()) { Text("Choose alarm / notification sound") }
                                Text("You can choose a sound available on your phone, or choose Silent.", fontSize = 12.sp)
                                Text("Reminder examples: 08:00, 13:00, 20:00", fontSize = 12.sp)
                            }
                        }
                    }
                }
                item { Text("Your dates & savings", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                if (rows.isEmpty()) item { Text("No entries yet. Add your first date and amount above.") }
                items(rows, key = { it.id }) { row ->
                    Card {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = row.done, onCheckedChange = { checked ->
                                rows = rows.map { if (it.id == row.id) it.copy(done = checked) else it }; saveRows(prefs, rows)
                            })
                            Column(Modifier.weight(1f)) {
                                Text(row.date, fontWeight = FontWeight.SemiBold)
                                Text(if (row.done) "Saved" else "Not saved", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("₹${row.amount}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            TextButton(onClick = { rows = rows.filterNot { it.id == row.id }; saveRows(prefs, rows) }) { Text("Delete") }
                        }
                    }
                }
                item { Text("Your entries and checkmarks are stored on this phone.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

fun loadRows(p: android.content.SharedPreferences): List<Saving> = try {
    val a = JSONArray(p.getString("rows", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { Saving(it.getLong("id"), it.getString("date"), it.getInt("amount"), it.getBoolean("done")) } }
} catch (_: Exception) { emptyList() }

fun saveRows(p: android.content.SharedPreferences, rows: List<Saving>) {
    val a = JSONArray()
    rows.forEach { a.put(JSONObject().put("id", it.id).put("date", it.date).put("amount", it.amount).put("done", it.done)) }
    p.edit().putString("rows", a.toString()).apply()
}

fun scheduleDaily(context: Context, time: String, index: Int) {
    try {
        val parts = time.split(":")
        val hour = parts[0].toInt(); val minute = parts[1].toInt()
        if (hour !in 0..23 || minute !in 0..59) return
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    } catch (_: Exception) { }
}
