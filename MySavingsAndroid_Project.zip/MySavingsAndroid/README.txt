MY SAVINGS — ANDROID STUDIO PROJECT

Included:
- Add any date and any rupee amount (for example ₹1, ₹2, ₹3 or ₹10).
- Mark entries as saved / not saved.
- Today's saved total and overall saved total.
- Editable savings target.
- Light/dark theme switch.
- Three configurable daily reminder times.
- Choose a notification/alarm sound from sounds available on the phone, or choose Silent.

IMPORTANT:
This is an Android Studio source project, not a precompiled APK.
To build the APK:
1. Install Android Studio on a computer.
2. Open this folder (MySavingsAndroid) in Android Studio.
3. Let Gradle sync complete.
4. Connect an Android phone or use an emulator.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The APK will be created under app/build/outputs/apk/debug/.

On Android 13+, allow notification permission when the app first opens.
For reminders, open the bell/settings icon, enter times in 24-hour HH:MM format,
then tap "Save & schedule reminders". Use "Choose alarm / notification sound" to pick a phone sound or Silent. Android notification-channel settings can also override the sound. Android battery settings may affect delivery.
This starter uses inexact daily alarms, so reminders may be a little late.

Default reminder times are 08:00, 13:00, 20:00.
